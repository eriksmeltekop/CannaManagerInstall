DOMAIN = "cannabis_grow_manager"
DEFAULT_NAME = "Cannabis Grow Manager"